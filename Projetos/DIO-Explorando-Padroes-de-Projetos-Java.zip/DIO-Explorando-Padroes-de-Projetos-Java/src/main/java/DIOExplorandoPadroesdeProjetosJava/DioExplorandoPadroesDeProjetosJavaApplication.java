package DIOExplorandoPadroesdeProjetosJava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DioExplorandoPadroesDeProjetosJavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DioExplorandoPadroesDeProjetosJavaApplication.class, args);
	}

}
